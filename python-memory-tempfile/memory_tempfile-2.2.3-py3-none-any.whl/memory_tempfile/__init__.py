from memory_tempfile.memory_tempfile import MemoryTempfile, MEM_BASED_FS, SUITABLE_PATHS

__version__ = '0.1.0'
