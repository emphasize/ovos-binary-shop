from ovos_config.meta import *
from ovos_utils.log import LOG
LOG.warning("This reference is deprecated, "
            "import from ovos_config.meta")
