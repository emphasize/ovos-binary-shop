"""
This module contains dead code only
All code here is in life support and available only for backwards api compatibility
Bug fixes will be made to maintain compatibility but are very low priority!

use ovos simple audio plugin instead
"""
from mycroft.deprecated.audio.services.simple import *
