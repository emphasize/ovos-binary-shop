"""
This module contains back compat imports only
Speech client moved into mycroft.listener module
"""
from mycroft.listener.mic import *
