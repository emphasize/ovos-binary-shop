"""
This module contains back compat imports only
Text client moved into ovos_cli_client package
"""
from mycroft.deprecated.text.text_client import *
