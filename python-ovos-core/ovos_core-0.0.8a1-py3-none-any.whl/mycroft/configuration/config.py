# backwards compat - moved to own python package
from ovos_config.config import *
from ovos_config.locations import *

