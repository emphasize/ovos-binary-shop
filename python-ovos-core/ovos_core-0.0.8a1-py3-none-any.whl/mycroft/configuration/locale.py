# backwards compat - moved to own python package
from ovos_config.locale import *
