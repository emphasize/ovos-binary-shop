# backwards compat import, moved to ovos_backend_client package
from ovos_backend_client.identity import DeviceIdentity, IdentityManager, identity_lock
