# backwards compat import
from ovos_utils.process_utils import Signal, PIDLock as Lock
Lock.init()
