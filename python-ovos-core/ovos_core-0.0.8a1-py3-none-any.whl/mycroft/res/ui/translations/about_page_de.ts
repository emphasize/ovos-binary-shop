<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de" sourcelanguage="en">
<context>
    <name>about_page</name>
    <message>
        <location filename="about_page.qml" line="45"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="77"/>
        <source>System Information</source>
        <translation>Systeminfo</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="89"/>
        <source>Kernel Version</source>
        <translation>Kernel Version</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="105"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="113"/>
        <location filename="about_page.qml" line="122"/>
        <source>Local Address</source>
        <translation>Lokale Adresse</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="122"/>
        <source>No Active Connection</source>
        <translation>Keine aktive Verbindung</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="165"/>
        <source>Device Settings</source>
        <translation>Geräteeinstellungen</translation>
    </message>
</context>
</TS>
