<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>about_page</name>
    <message>
        <location filename="about_page.qml" line="45"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="77"/>
        <source>System Information</source>
        <translation>Información del sistema</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="89"/>
        <source>Kernel Version</source>
        <translation>Versión del núcleo</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="105"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="113"/>
        <location filename="about_page.qml" line="122"/>
        <source>Local Address</source>
        <translation>Dirección local</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="122"/>
        <source>No Active Connection</source>
        <translation>Sin conexión activa</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="165"/>
        <source>Device Settings</source>
        <translation>Configuración de dispositivo</translation>
    </message>
</context>
</TS>
