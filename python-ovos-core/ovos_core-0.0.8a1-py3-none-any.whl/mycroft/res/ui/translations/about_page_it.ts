<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>about_page</name>
    <message>
        <location filename="about_page.qml" line="45"/>
        <source>About</source>
        <translation>Di</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="77"/>
        <source>System Information</source>
        <translation>Informazioni di sistema</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="89"/>
        <source>Kernel Version</source>
        <translation>Versione kernel</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="105"/>
        <source>Version</source>
        <translation>Versione</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="113"/>
        <location filename="about_page.qml" line="122"/>
        <source>Local Address</source>
        <translation>Indirizzo locale</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="122"/>
        <source>No Active Connection</source>
        <translation>Nessuna connessione attiva</translation>
    </message>
    <message>
        <location filename="about_page.qml" line="165"/>
        <source>Device Settings</source>
        <translation>Impostazioni dispositivo</translation>
    </message>
</context>
</TS>
