<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>configuration_generator_display</name>
    <message>
        <location filename="configuration_generator_display.qml" line="86"/>
        <source>Configuration</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <location filename="configuration_generator_display.qml" line="279"/>
        <source>Back</source>
        <translation>atrás</translation>
    </message>
    <message>
        <location filename="configuration_generator_display.qml" line="309"/>
        <source>Update Settings</source>
        <translation>Ajustes de actualización</translation>
    </message>
</context>
</TS>
