<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>configuration_groups_display</name>
    <message>
        <location filename="configuration_groups_display.qml" line="43"/>
        <source>Advanced Configuration</source>
        <translation>Configurazione avanzata</translation>
    </message>
    <message>
        <location filename="configuration_groups_display.qml" line="152"/>
        <source>Back</source>
        <translation>Di ritorno</translation>
    </message>
</context>
</TS>
