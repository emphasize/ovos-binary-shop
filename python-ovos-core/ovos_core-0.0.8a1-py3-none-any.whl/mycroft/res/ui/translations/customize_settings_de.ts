<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>customize_settings</name>
    <message>
        <location filename="customize_settings.qml" line="60"/>
        <source>Customize Settings</source>
        <translation>Einstellungen anpassen</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="264"/>
        <source>Device Settings</source>
        <translation>Geräteeinstellungen</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="294"/>
        <source>Create Scheme</source>
        <translation>Schema erstellen</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="399"/>
        <source>Select Style</source>
        <translation>Stilauswahl</translation>
    </message>
    <message>
        <location filename="customize_settings.qml" line="468"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
</TS>
