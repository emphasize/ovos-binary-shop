<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>developer_settings</name>
    <message>
        <location filename="developer_settings.qml" line="48"/>
        <source>Developer Settings</source>
        <translation>Configuración del desarrollador</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="117"/>
        <source>Advanced Settings</source>
        <translation>Ajustes avanzados</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="152"/>
        <source>Enable Dashboard</source>
        <translation>Habilitar panel</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="165"/>
        <source>Disable Dashboard</source>
        <translation>Deshabilitar panel</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="187"/>
        <source>Dashboard Address</source>
        <translation>Dirección del tablero</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="197"/>
        <source>Dashboard Username</source>
        <translation>Nombre de usuario del panel</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="207"/>
        <source>Dashboard Password</source>
        <translation>Contraseña del panel</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="250"/>
        <source>Device Settings</source>
        <translation>Configuración de dispositivo</translation>
    </message>
</context>
</TS>
