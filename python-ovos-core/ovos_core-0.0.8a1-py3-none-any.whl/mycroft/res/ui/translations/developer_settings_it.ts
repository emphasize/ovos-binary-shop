<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>developer_settings</name>
    <message>
        <location filename="developer_settings.qml" line="48"/>
        <source>Developer Settings</source>
        <translation>Paramètres du développeur</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="117"/>
        <source>Advanced Settings</source>
        <translation>Impostazioni avanzate</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="152"/>
        <source>Enable Dashboard</source>
        <translation>Abilita dashboard</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="165"/>
        <source>Disable Dashboard</source>
        <translation>Disabilita dashboard</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="187"/>
        <source>Dashboard Address</source>
        <translation>Indirizzo dashboard</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="197"/>
        <source>Dashboard Username</source>
        <translation>Nome utente dashboard</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="207"/>
        <source>Dashboard Password</source>
        <translation>Password dashboard</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="250"/>
        <source>Device Settings</source>
        <translation>Impostazioni dispositivo</translation>
    </message>
</context>
</TS>
