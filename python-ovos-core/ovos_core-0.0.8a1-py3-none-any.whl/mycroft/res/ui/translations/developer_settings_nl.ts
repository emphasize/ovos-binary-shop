<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>developer_settings</name>
    <message>
        <location filename="developer_settings.qml" line="48"/>
        <source>Developer Settings</source>
        <translation>Ontwikkelaarsinstellingen</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="117"/>
        <source>Advanced Settings</source>
        <translation>Geavanceerde instellingen</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="152"/>
        <source>Enable Dashboard</source>
        <translation>Dashboard inschakelen</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="165"/>
        <source>Disable Dashboard</source>
        <translation>Dashboard uitschakelen</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="187"/>
        <source>Dashboard Address</source>
        <translation>Dashboardadres</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="197"/>
        <source>Dashboard Username</source>
        <translation>Dashboard-gebruikersnaam</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="207"/>
        <source>Dashboard Password</source>
        <translation>Dashboardwachtwoord</translation>
    </message>
    <message>
        <location filename="developer_settings.qml" line="250"/>
        <source>Device Settings</source>
        <translation>Apparaat instellingen</translation>
    </message>
</context>
</TS>
