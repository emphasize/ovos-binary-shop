<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>display_settings</name>
    <message>
        <location filename="display_settings.qml" line="47"/>
        <source>Display Settings</source>
        <translation>Configurações do visor</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="78"/>
        <source>Wallpaper Rotation</source>
        <translation>Rotação do papel de parede</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="89"/>
        <source>Changes the wallpaper automatically</source>
        <translation>Muda o papel de parede automaticamente</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="107"/>
        <location filename="display_settings.qml" line="167"/>
        <location filename="display_settings.qml" line="227"/>
        <source>ON</source>
        <translation>SOBRE</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="107"/>
        <location filename="display_settings.qml" line="167"/>
        <location filename="display_settings.qml" line="227"/>
        <source>OFF</source>
        <translation>DESLIGADO</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="138"/>
        <source>Auto Dim</source>
        <translation>ESCURECIMENTO AUTOMÁTICO</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="149"/>
        <source>Dim&apos;s the display in 60 seconds</source>
        <translation>Escureça a tela em 60 segundos</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="198"/>
        <source>Auto Nightmode</source>
        <translation>Modo noturno automático</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="209"/>
        <source>Activates nightmode on homescreen, depending on the time of the day</source>
        <translation>Ativa o modo noturno na tela inicial, dependendo da hora do dia</translation>
    </message>
    <message>
        <location filename="display_settings.qml" line="284"/>
        <source>Device Settings</source>
        <translation>Configurações do dispositivo</translation>
    </message>
</context>
</TS>
