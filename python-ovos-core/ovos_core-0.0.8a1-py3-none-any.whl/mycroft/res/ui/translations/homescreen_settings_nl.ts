<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nl_NL">
<context>
    <name>homescreen_settings</name>
    <message>
        <location filename="homescreen_settings.qml" line="61"/>
        <source>Homescreen Settings</source>
        <translation>Instellingen startscherm</translation>
    </message>
    <message>
        <location filename="homescreen_settings.qml" line="169"/>
        <source>Device Settings</source>
        <translation>Apparaat instellingen</translation>
    </message>
</context>
</TS>
