<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>settingListBox</name>
    <message>
        <location filename="configuration_ui/settingListBox.qml" line="183"/>
        <source>Type here to add an item to the list</source>
        <translation>Escriba aquí para agregar un elemento a la lista</translation>
    </message>
    <message>
        <location filename="configuration_ui/settingListBox.qml" line="196"/>
        <source>Add Item</source>
        <translation>Añadir artículo</translation>
    </message>
</context>
</TS>
