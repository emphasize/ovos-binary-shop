<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>settingListBox</name>
    <message>
        <location filename="configuration_ui/settingListBox.qml" line="183"/>
        <source>Type here to add an item to the list</source>
        <translation>Digite aqui para adicionar um item à lista</translation>
    </message>
    <message>
        <location filename="configuration_ui/settingListBox.qml" line="196"/>
        <source>Add Item</source>
        <translation>Adicionar Item</translation>
    </message>
</context>
</TS>
