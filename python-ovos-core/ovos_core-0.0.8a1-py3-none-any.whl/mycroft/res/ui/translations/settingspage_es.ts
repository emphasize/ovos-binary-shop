<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>settingspage</name>
    <message>
        <location filename="settingspage.qml" line="19"/>
        <source>Homescreen Settings</source>
        <translation>Configuración de la pantalla de inicio</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="25"/>
        <source>Customize</source>
        <translation>personalizar</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="31"/>
        <source>Display</source>
        <translation>Monitor</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="37"/>
        <source>Enable SSH</source>
        <translation>Habilitar SSH</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="43"/>
        <source>Developer Settings</source>
        <translation>Configuración del desarrollador</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="49"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="68"/>
        <source>Device Settings</source>
        <translation>Configuración de dispositivo</translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="180"/>
        <source>Home</source>
        <translation>Hogar</translation>
    </message>
</context>
</TS>
