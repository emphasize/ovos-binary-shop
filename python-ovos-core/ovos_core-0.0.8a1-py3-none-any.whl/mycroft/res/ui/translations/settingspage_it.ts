<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>settingspage</name>
    <message>
        <location filename="settingspage.qml" line="19"/>
        <source>Homescreen Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="25"/>
        <source>Customize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="31"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="37"/>
        <source>Enable SSH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="43"/>
        <source>Developer Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="49"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="68"/>
        <source>Device Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settingspage.qml" line="180"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
