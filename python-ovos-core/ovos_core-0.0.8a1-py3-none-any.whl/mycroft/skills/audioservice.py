# this was moved in order to allow importing it without dragging skills service dependencies
from mycroft.audio.interface import AudioService
