from mycroft.skills.intent_services.adapt_service \
    import AdaptService, AdaptIntent
from mycroft.skills.intent_services.base import IntentMatch
from mycroft.skills.intent_services.fallback_service import FallbackService
from mycroft.skills.intent_services.padatious_service \
    import PadatiousService, PadatiousMatcher
from mycroft.skills.intent_services.converse_service import ConverseService
from mycroft.skills.intent_services.commonqa_service import CommonQAService
