"""
This module contains back compat imports only
logic moved into mycroft.audio module and ovos plugin manager
"""
from mycroft.deprecated.stt import *
