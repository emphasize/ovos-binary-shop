# backwards compat import, now a standalone package https://github.com/forslund/combo-lock
from combo_lock import ComboLock
