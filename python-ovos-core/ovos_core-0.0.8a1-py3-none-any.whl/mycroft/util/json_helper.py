# backwards compat import for mycroft-core
# this code is maintained as part of ovos_utils
from ovos_utils.json_helper import merge_dict, load_commented_json, uncomment_json
