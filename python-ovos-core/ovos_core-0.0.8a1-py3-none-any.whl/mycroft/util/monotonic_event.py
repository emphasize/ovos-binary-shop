# backwards compat import
from ovos_utils.process_utils import MonotonicEvent

