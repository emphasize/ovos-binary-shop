# backwards compat import for mycroft-core
# this code is maintained as part of ovos_utils
from ovos_utils.signal import get_ipc_directory, create_signal, \
    check_for_signal
