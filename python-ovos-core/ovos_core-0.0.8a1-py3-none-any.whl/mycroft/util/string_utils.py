# backwards compat import for mycroft-core
# this code is maintained as part of ovos_utils
from ovos_utils import camel_case_split
