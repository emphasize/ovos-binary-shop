#
# Copyright 2017 Mycroft AI Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from typing import List
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

from lingua_franca.time import now_local
from lingua_franca.lang.parse_common import is_numeric, look_for_fractions, \
    invert_dict, ReplaceableNumber, partition_list, tokenize, Token, Normalizer
from lingua_franca.lang.common_data_az import _LONG_SCALE_AZ, \
    _SHORT_SCALE_AZ, _NEGATIVES_AZ, _SUMS_AZ, _MULTIPLIES_LONG_SCALE_AZ, \
    _MULTIPLIES_SHORT_SCALE_AZ, _FRACTION_MARKER_AZ, _DECIMAL_MARKER_AZ, \
    _STRING_NUM_AZ, _STRING_SHORT_ORDINAL_AZ, _STRING_LONG_ORDINAL_AZ, \
    _FRACTION_STRING_AZ, _generate_plurals_az, _SPOKEN_EXTRA_NUM_AZ

import re
import json
from lingua_franca.internal import resolve_resource_file

def _convert_words_to_numbers_az(text, short_scale=True, ordinals=False):
    """
    Convert words in a string into their equivalent numbers.
    Args:
        text str:
        short_scale boolean: True if short scale numbers should be used.
        ordinals boolean: True if ordinals (e.g. birinci, ikinci, üçüncü) should
                          be parsed to their number values (1, 2, 3...)

    Returns:
        str
        The original text, with numbers subbed in where appropriate.

    """
    tokens = tokenize(text)
    numbers_to_replace = \
        _extract_numbers_with_text_az(tokens, short_scale, ordinals)

    numbers_to_replace.sort(key=lambda number: number.start_index)

    results = []
    for token in tokens:
        if not numbers_to_replace or \
                token.index < numbers_to_replace[0].start_index:
            results.append(token.word)
        else:
            if numbers_to_replace and \
                    token.index == numbers_to_replace[0].start_index:
                results.append(str(numbers_to_replace[0].value))
            if numbers_to_replace and \
                    token.index == numbers_to_replace[0].end_index:
                numbers_to_replace.pop(0)

    return ' '.join(results)


def _extract_numbers_with_text_az(tokens, short_scale=True,
                                  ordinals=False, fractional_numbers=True):
    """
    Extract all numbers from a list of Tokens, with the words that
    represent them.

    Args:
        [Token]: The tokens to parse.
        short_scale bool: True if short scale numbers should be used, False for
                          long scale. True by default.
        ordinals bool: True if ordinal words (birinci, ikinci, üçüncü, etc) should
                       be parsed.
        fractional_numbers bool: True if we should look for fractions and
                                 decimals.

    Returns:
        [ReplaceableNumber]: A list of tuples, each containing a number and a
                         string.

    """
    placeholder = "<placeholder>"  # inserted to maintain correct indices
    results = []
    while True:
        to_replace = \
            _extract_number_with_text_az(tokens, short_scale,
                                         ordinals, fractional_numbers)
        if not to_replace:
            break

        results.append(to_replace)

        tokens = [
            t if not
            to_replace.start_index <= t.index <= to_replace.end_index
            else
            Token(placeholder, t.index) for t in tokens
        ]
    results.sort(key=lambda n: n.start_index)
    return results


def _extract_number_with_text_az(tokens, short_scale=True,
                                 ordinals=False, fractional_numbers=True):
    """
    This function extracts a number from a list of Tokens.

    Args:
        tokens str: the string to normalize
        short_scale (bool): use short scale if True, long scale if False
        ordinals (bool): consider ordinal numbers
        fractional_numbers (bool): True if we should look for fractions and
                                   decimals.
    Returns:
        ReplaceableNumber

    """
    number, tokens = \
        _extract_number_with_text_az_helper(tokens, short_scale,
                                            ordinals, fractional_numbers)
    return ReplaceableNumber(number, tokens)


def _extract_number_with_text_az_helper(tokens,
                                        short_scale=True, ordinals=False,
                                        fractional_numbers=True):
    """
    Helper for _extract_number_with_text_az.

    This contains the real logic for parsing, but produces
    a result that needs a little cleaning (specific, it may
    contain leading articles that can be trimmed off).

    Args:
        tokens [Token]:
        short_scale boolean:
        ordinals boolean:
        fractional_numbers boolean:

    Returns:
        int or float, [Tokens]

    """
    if fractional_numbers:
        fraction, fraction_text = \
            _extract_fraction_with_text_az(tokens, short_scale, ordinals)
        if fraction:
            # print("fraction")
            return fraction, fraction_text

        decimal, decimal_text = \
            _extract_decimal_with_text_az(tokens, short_scale, ordinals)
        if decimal:
            # print("decimal")
            return decimal, decimal_text

    return _extract_whole_number_with_text_az(tokens, short_scale, ordinals)


def _extract_fraction_with_text_az(tokens, short_scale, ordinals):
    """
    Extract fraction numbers from a string.

    This function handles text such as '2 və dörddə üç'. Note that "yarım" or
    similar will be parsed by the whole number function.

    Args:
        tokens [Token]: words and their indexes in the original string.
        short_scale boolean:
        ordinals boolean:

    Returns:
        (int or float, [Token])
        The value found, and the list of relevant tokens.
        (None, None) if no fraction value is found.

    """
    for c in _FRACTION_MARKER_AZ:
        partitions = partition_list(tokens, lambda t: t.word == c)
        
        if len(partitions) == 3:
            numbers1 = \
                _extract_numbers_with_text_az(partitions[0], short_scale,
                                              ordinals, fractional_numbers=False)
            numbers2 = \
                _extract_numbers_with_text_az(partitions[2], short_scale,
                                              ordinals, fractional_numbers=True)

            if not numbers1 or not numbers2:
                return None, None

            # ensure first is not a fraction and second is a fraction
            num1 = numbers1[-1]
            num2 = numbers2[0]
            if num1.value >= 1 and 0 < num2.value < 1:
                return num1.value + num2.value, \
                    num1.tokens + partitions[1] + num2.tokens

    return None, None


def _extract_decimal_with_text_az(tokens, short_scale, ordinals):
    """
    Extract decimal numbers from a string.

    This function handles text such as '2 nöqtə 5'.

    Notes:
        While this is a helper for extractnumber_az, it also depends on
        extractnumber_az, to parse out the components of the decimal.

        This does not currently handle things like:
            number dot number number number

    Args:
        tokens [Token]: The text to parse.
        short_scale boolean:
        ordinals boolean:

    Returns:
        (float, [Token])
        The value found and relevant tokens.
        (None, None) if no decimal value is found.

    """
    for c in _DECIMAL_MARKER_AZ:
        partitions = partition_list(tokens, lambda t: t.word == c)

        if len(partitions) == 3:
            numbers1 = \
                _extract_numbers_with_text_az(partitions[0], short_scale,
                                              ordinals, fractional_numbers=False)
            numbers2 = \
                _extract_numbers_with_text_az(partitions[2], short_scale,
                                              ordinals, fractional_numbers=False)
            if not numbers1 or not numbers2:
                return None, None

            number = numbers1[-1]
            decimal = numbers2[0]

            # TODO handle number dot number number number
            if "." not in str(decimal.text):
                return number.value + float('0.' + str(decimal.value)), \
                    number.tokens + partitions[1] + decimal.tokens
    return None, None


def _extract_whole_number_with_text_az(tokens, short_scale, ordinals):
    """
    Handle numbers not handled by the decimal or fraction functions. This is
    generally whole numbers. Note that phrases such as "yarım" will be
    handled by this function.

    Args:
        tokens [Token]:
        short_scale boolean:
        ordinals boolean:

    Returns:
        int or float, [Tokens]
        The value parsed, and tokens that it corresponds to.

    """
    multiplies, string_num_ordinal, string_num_scale = \
        _initialize_number_data_az(short_scale, speech=ordinals is not None)

    number_words = []  # type: List[Token]
    val = False
    prev_val = None
    next_val = None
    to_sum = []
    # print(tokens, ordinals)
    for idx, token in enumerate(tokens):
        current_val = None
        if next_val:
            next_val = None
            continue

        word = token.word.lower()
        if word in _NEGATIVES_AZ:
            number_words.append(token)
            continue

        prev_word = tokens[idx - 1].word.lower() if idx > 0 else ""
        next_word = tokens[idx + 1].word.lower() if idx + 1 < len(tokens) else ""
        # print(prev_word, word, next_word, number_words)
        if word not in string_num_scale and \
                word not in _STRING_NUM_AZ and \
                word not in _SUMS_AZ and \
                word not in multiplies and \
                not (ordinals and word in string_num_ordinal) and \
                not is_numeric(word) and \
                not is_fractional_az(word, short_scale=short_scale) and \
                not look_for_fractions(word.split('/')):
            # print("a1")
            words_only = [token.word for token in number_words]

            if number_words and not all([w.lower() in
                                         _NEGATIVES_AZ for w in words_only]):
                break
            else:
                number_words = []
                continue
        elif word not in multiplies \
                and word not in _SPOKEN_EXTRA_NUM_AZ \
                and prev_word not in multiplies \
                and prev_word not in _SUMS_AZ \
                and not (ordinals and prev_word in string_num_ordinal) \
                and prev_word not in _NEGATIVES_AZ:
            number_words = [token]
            # print("a2")
        elif prev_word in _SUMS_AZ and word in _SUMS_AZ:
            number_words = [token]
            # print("a3")
        elif ordinals is None and \
                (word in string_num_ordinal or word in _SPOKEN_EXTRA_NUM_AZ):
            # print("a4")
            # flagged to ignore this token
            continue
        else:
            # print("a5")
            number_words.append(token)

        # is this word already a number ?
        if is_numeric(word):
            # print("b")
            if word.isdigit():  # doesn't work with decimals
                val = int(word)
            else:
                val = float(word)
            current_val = val

        # is this word the name of a number ?
        if word in _STRING_NUM_AZ:
            val = _STRING_NUM_AZ.get(word)
            current_val = val
            # print("c1", current_val)
        elif word in string_num_scale:
            val = string_num_scale.get(word)
            current_val = val
            # print("c2")
        elif ordinals and word in string_num_ordinal:
            val = string_num_ordinal[word]
            current_val = val
            # print("c3")
        # is the prev word a number and should we sum it?
        # twenty two, fifty six
        if (prev_word in _SUMS_AZ and val and val < 10) or all([prev_word in
                                                                multiplies,
                                                                val < prev_val if prev_val else False]):
            val = prev_val + val
            # print("d")

        # is the prev word a number and should we multiply it?
        # twenty hundred, six hundred
        if word in multiplies:
            if not prev_val:
                prev_val = 1
            val = prev_val * val
            # print("e")

        # is this a spoken fraction?
        # 1 yarım fincan - yarım fincan
        if current_val is None and not (ordinals is None and word in _SPOKEN_EXTRA_NUM_AZ):
            val = is_fractional_az(word, short_scale=short_scale,
                                   spoken=ordinals is not None)
            if val:
                if prev_val:
                    val += prev_val
                current_val = val
                # print("f", current_val, prev_val)
                if word in _SPOKEN_EXTRA_NUM_AZ:
                    break

        # dörddə bir
        if ordinals is False:
            temp = prev_val
            prev_val = is_fractional_az(prev_word, short_scale=short_scale)
            if prev_val:
                if not val:
                    val = 1
                val = val * prev_val
                if idx + 1 < len(tokens):
                    number_words.append(tokens[idx + 1])
            else:
                prev_val = temp
            # print("g", prev_val)

        # is this a negative number?
        if val and prev_word and prev_word in _NEGATIVES_AZ:
            val = 0 - val
            # print("h")

        # let's make sure it isn't a fraction
        if not val:
            # look for fractions like "2/3"
            aPieces = word.split('/')
            if look_for_fractions(aPieces):
                val = float(aPieces[0]) / float(aPieces[1])
                current_val = val
            # print("i")

        else:
            if current_val and all([
                prev_word in _SUMS_AZ,
                word not in _SUMS_AZ,
                word not in multiplies,
                current_val >= 10]):
                # Backtrack - we've got numbers we can't sum.
                # print("j", number_words, prev_val)
                number_words.pop()
                val = prev_val
                break
            prev_val = val

            if word in multiplies and next_word not in multiplies:
                # handle long numbers
                # six hundred sixty six
                # two million five hundred thousand
                #
                # This logic is somewhat complex, and warrants
                # extensive documentation for the next coder's sake.
                #
                # The current word is a power of ten. `current_val` is
                # its integer value. `val` is our working sum
                # (above, when `current_val` is 1 million, `val` is
                # 2 million.)
                #
                # We have a dict `string_num_scale` containing [value, word]
                # pairs for "all" powers of ten: string_num_scale[10] == "ten.
                #
                # We need go over the rest of the tokens, looking for other
                # powers of ten. If we find one, we compare it with the current
                # value, to see if it's smaller than the current power of ten.
                #
                # Numbers which are not powers of ten will be passed over.
                #
                # If all the remaining powers of ten are smaller than our
                # current value, we can set the current value aside for later,
                # and begin extracting another portion of our final result.
                # For example, suppose we have the following string.
                # The current word is "million".`val` is 9000000.
                # `current_val` is 1000000.
                #
                #    "nine **million** nine *hundred* seven **thousand**
                #     six *hundred* fifty seven"
                #
                # Iterating over the rest of the string, the current
                # value is larger than all remaining powers of ten.
                #
                # The if statement passes, and nine million (9000000)
                # is appended to `to_sum`.
                #
                # The main variables are reset, and the main loop begins
                # assembling another number, which will also be appended
                # under the same conditions.
                #
                # By the end of the main loop, to_sum will be a list of each
                # "place" from 100 up: [9000000, 907000, 600]
                #
                # The final three digits will be added to the sum of that list
                # at the end of the main loop, to produce the extracted number:
                #
                #    sum([9000000, 907000, 600]) + 57
                # == 9,000,000 + 907,000 + 600 + 57
                # == 9,907,657
                #
                # >>> foo = "nine million nine hundred seven thousand six
                #            hundred fifty seven"
                # >>> extract_number(foo)
                # 9907657
                # print("k", tokens[idx+1:])
                time_to_sum = True
                for other_token in tokens[idx+1:]:
                    if other_token.word.lower() in multiplies:
                        if string_num_scale[other_token.word.lower()] >= current_val:
                            time_to_sum = False
                        else:
                            continue
                    if not time_to_sum:
                        break
                if time_to_sum:
                    # print("l")
                    to_sum.append(val)
                    val = 0
                    prev_val = 0

    if val is not None and to_sum:
        # print("m", to_sum)
        val += sum(to_sum)
    # print(val, number_words, "end")
    return val, number_words


def _initialize_number_data_az(short_scale, speech=True):
    """
    Generate dictionaries of words to numbers, based on scale.

    This is a helper function for _extract_whole_number.

    Args:
        short_scale (bool):
        speech (bool): consider extra words (_SPOKEN_EXTRA_NUM_AZ) to be numbers

    Returns:
        (set(str), dict(str, number), dict(str, number))
        multiplies, string_num_ordinal, string_num_scale

    """
    multiplies = _MULTIPLIES_SHORT_SCALE_AZ if short_scale \
        else _MULTIPLIES_LONG_SCALE_AZ

    string_num_ordinal_az = _STRING_SHORT_ORDINAL_AZ if short_scale \
        else _STRING_LONG_ORDINAL_AZ

    string_num_scale_az = _SHORT_SCALE_AZ if short_scale else _LONG_SCALE_AZ
    string_num_scale_az = invert_dict(string_num_scale_az)

    return multiplies, string_num_ordinal_az, string_num_scale_az


def extract_number_az(text, short_scale=True, ordinals=False):
    """
    This function extracts a number from a text string,
    handles pronunciations in long scale and short scale

    https://en.wikipedia.org/wiki/Names_of_large_numbers

    Args:
        text (str): the string to normalize
        short_scale (bool): use short scale if True, long scale if False
        ordinals (bool): consider ordinal numbers
    Returns:
        (int) or (float) or False: The extracted number or False if no number
                                   was found

    """
    return _extract_number_with_text_az(tokenize(text.lower()),
                                        short_scale, ordinals).value


def extract_duration_az(text):
    """
    Convert an azerbaijani phrase into a number of seconds

    Convert things like:
        "10 dəqiqə"
        "2 yarım saat"
        "3 gün 8 saat 10 dəqiqə 49 saniyə"
    into an int, representing the total number of seconds.

    The words used in the duration will be consumed, and
    the remainder returned.

    As an example, "5 dəqiqəyə taymer qur" would return
    (300, "taymer qur").

    Args:
        text (str): string containing a duration

    Returns:
        (timedelta, str):
                    A tuple containing the duration and the remaining text
                    not consumed in the parsing. The first value will
                    be None if no duration is found. The text returned
                    will have whitespace stripped from the ends.
    """
    if not text:
        return None

    time_units = {
        'microseconds': 0,
        'milliseconds': 0,
        'seconds': 0,
        'minutes': 0,
        'hours': 0,
        'days': 0,
        'weeks': 0
    }

    time_units_az = {
        'mikrosaniyə': 'microseconds',
        'milisaniyə': 'milliseconds',
        'saniyə': 'seconds',
        'dəqiqə': 'minutes',
        'saat': 'hours',
        'gün': 'days',
        'həftə': 'weeks'
    }

    pattern = r"(?P<value>\d+(?:\.?\d+)?)(?:\s+|\-){unit}?(?:yə|a|ə)?(?:(?:\s|,)+)?(?P<half>yarım|0\.5)?(?:a)?"
    text = _convert_words_to_numbers_az(text)
    for unit_az in time_units_az:
        unit_pattern = pattern.format(unit=unit_az)
        def repl(match):
            time_units[time_units_az[unit_az]] += float(match.group(1)) + (0.5 if match.group(2) else 0)
            return ''
        text = re.sub(unit_pattern, repl, text)

    text = text.strip()
    duration = timedelta(**time_units) if any(time_units.values()) else None

    return (duration, text)


def extract_datetime_az(text, anchorDate=None, default_time=None):
    """ Convert a human date reference into an exact datetime

    Convert things like
        "bu gün"
        "sabah günortadan sonra"
        "gələn çərşənbə axşamı günorta 4 də"
        "3 avqust"
    into a datetime.  If a reference date is not provided, the current
    local time is used.  Also consumes the words used to define the date
    returning the remaining string.  For example, the string
       "çərşənbə axşamı hava necədir"
    returns the date for the forthcoming çərşənbə axşamı relative to the reference
    date and the remainder string
       "hava necədir".

    The "gələn" instance of a day or weekend is considered to be no earlier than
    48 hours in the future. On Friday, "gələn Bazar ertəsi" would be in 3 days.
    On Saturday, "gələn Bazar ertəsi" would be in 9 days.

    Args:
        text (str): string containing date words
        anchorDate (datetime): A reference date/time for "sabah", etc
        default_time (time): Time to set if no time was found in the string

    Returns:
        [datetime, str]: An array containing the datetime and the remaining
                         text not consumed in the parsing, or None if no
                         date or time related text was found.
    """

    def clean_string(s, word_list):
        # normalize and lowercase utt  (replaces words with numbers)
        s = _convert_words_to_numbers_az(s, ordinals=None)
        # clean unneeded punctuation and capitalization among other things.
        s = s.lower().replace('?', '').replace('.', '').replace(',', '')

        wordList = s.split()
        skip_next_word = False
        new_words = []
        for idx, word in enumerate(wordList):
            if skip_next_word:
                skip_next_word = False
                continue
            wordNext = wordList[idx + 1] if idx + 1 < len(wordList) else ""
            ordinals = ["ci", "cü", "cı", "cu"]
            if word[0].isdigit():
                for ordinal in ordinals:
                    if ordinal in wordNext:
                        skip_next_word = True
            if ((word == "bu" and wordNext == "gün") or
               (word in ['cümə', 'çərşənbə'] and 'axşamı'in wordNext) or
                (word == 'bazar' and 'ertəsi' in wordNext) or
                (word == 'günortadan' and wordNext == 'sonra') or
                (word == 'gecə' and 'yarısı' in wordNext)):
                word = word + ' ' + wordNext
                skip_next_word = True

            for orig_word in word_list:
                if word.startswith(orig_word):
                    word = orig_word
                    break

            new_words.append(word)

        return new_words

    def date_found():
        return found or \
            (
                datestr != "" or
                yearOffset != 0 or monthOffset != 0 or
                dayOffset is True or hrOffset != 0 or
                hrAbs or minOffset != 0 or
                minAbs or secOffset != 0
            )

    if not anchorDate:
        anchorDate = now_local()

    if text == "":
        return None

    found = False
    daySpecified = False
    dayOffset = False
    monthOffset = 0
    yearOffset = 0
    today = anchorDate.strftime("%w")
    currentYear = anchorDate.strftime("%Y")
    fromFlag = False
    datestr = ""
    hasYear = False
    timeQualifier = ""
    word_list = []
    timeQualifiersAM = ['səhər', 'gecə']
    timeQualifiersPM = ['günorta', 'axşam', 'nahar']
    word_list += timeQualifiersAM + timeQualifiersPM
    timeQualifiersList = set(timeQualifiersAM + timeQualifiersPM)
    markers = ['da', 'də', 'sonra', "ərzində", "günündən", "günü", "gündən", "gün"]
    days = ['bazar ertəsi', 'çərşənbə axşamı', 'çərşənbə',
            'cümə axşamı', 'cümə', 'şənbə', 'bazar']
    months = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun',
              'iyul', 'avqust', 'sentyabr', 'oktyabr', 'moyabr',
              'dekabr']
    eng_months = ['january', 'february', 'march', 'april', 'may', 'june',
                  'july', 'august', 'september', 'october', 'november',
                  'december']
    word_list += days + months
    recur_markers = days + [_generate_plurals_az(d) for d in days] + ['həftə sonu', 'iş günü',
                                                      'həftə sonları', 'iş günləri']
    monthsShort = ['yan', 'fev', 'mar', 'apr', 'may', 'ıyn', 'ıyl', 'avq',
                   'sen', 'okt', 'noy', 'dek']
    year_multiples = ["onillik", "yüzillik", "minillik"]
    day_multiples = ["həftə", "ay", "il"]
    word_list += year_multiples + day_multiples + ['saat', 'dəqiqə', 'saniyə', 'sonra', 'gecə yarısı', 'günortadan sonra', 'gün']
    word_list.sort(key=lambda x: len(x), reverse=True)
    words = clean_string(text, word_list)

    for idx, word in enumerate(words):
        if word == "":
            continue
        wordPrevPrev = words[idx - 2] if idx > 1 else ""
        wordPrev = words[idx - 1] if idx > 0 else ""
        wordNext = words[idx + 1] if idx + 1 < len(words) else ""
        wordNextNext = words[idx + 2] if idx + 2 < len(words) else ""
        wordNextNextNext = words[idx + 3] if idx + 3 < len(words) else ""

        start = idx
        used = 0
        # save timequalifier for later
        if word == "indi" and not datestr:
            resultStr = " ".join(words[idx + 1:])
            resultStr = ' '.join(resultStr.split())
            extractedDate = anchorDate.replace(microsecond=0)
            return [extractedDate, resultStr]
        elif wordNext in year_multiples:
            multiplier = None
            if is_numeric(word):
                multiplier = extract_number_az(word)
            multiplier = multiplier or 1
            multiplier = int(multiplier)
            used += 2
            if "onillik" in wordNext:
                yearOffset = multiplier * 10
            elif "yüzillik" in wordNext:
                yearOffset = multiplier * 100
            elif "minillik" in wordNext:
                yearOffset = multiplier * 1000
        elif word in timeQualifiersList:
            timeQualifier = word
        # parse bu qün, sabah, srağagün, dünən, birigün
        elif word == "bu gün" and not fromFlag:
            dayOffset = 0
            used += 1
        elif word == "sabah" and not fromFlag:
            dayOffset = 1
            used += 1
        elif word == "srağagün" and not fromFlag:
            dayOffset = -2
            used += 1
        elif word == "dünən" and not fromFlag:
            dayOffset = -1
            used += 1
        elif word == "birigün" and not fromFlag:
            dayOffset = 2
            used = 1
        # parse 5 gün, 10 həftə, keçən həftə, gələn həftə
        elif word == "gün":
            if wordPrev and wordPrev[0].isdigit():
                dayOffset += int(wordPrev)
                start -= 1
                used = 2
                if wordNext == "sonra":
                    used += 1
        elif word == "həftə" and not fromFlag and wordPrev:
            if wordPrev[0].isdigit():
                dayOffset += int(wordPrev) * 7
                start -= 1
                used = 2
                if wordNext == "sonra":
                    used += 1
            elif wordPrev == "gələn":
                dayOffset = 7
                start -= 1
                used = 2
                if wordNext == "sonra":
                    used += 1
            elif wordPrev == "keçən":
                dayOffset = -7
                start -= 1
                used = 2
        # parse 10 months, next month, last month
        elif word == "ay" and not fromFlag and wordPrev:
            if wordPrev[0].isdigit():
                monthOffset = int(wordPrev)
                start -= 1
                used = 2
            elif wordPrev == "gələn":
                monthOffset = 1
                start -= 1
                used = 2
            elif wordPrev == "keçən":
                monthOffset = -1
                start -= 1
                used = 2
        # parse 5 il, gələn il, keçən il
        elif word == "il" and not fromFlag and wordPrev:
            if wordPrev[0].isdigit():
                yearOffset = int(wordPrev)
                start -= 1
                used = 2
            elif wordPrev == "gələn":
                yearOffset = 1
                start -= 1
                used = 2
            elif wordPrev == "keçən":
                yearOffset = -1
                start -= 1
                used = 2
            if wordNext in markers:
                used += 1
        # parse Monday, Tuesday, etc., and next Monday,
        # last Tuesday, etc.
        elif word in days and not fromFlag:
            if wordNext in markers:
                used += 1
            d = days.index(word)
            dayOffset = (d + 1) - int(today)
            used += 1
            if dayOffset < 0:
                dayOffset += 7
            if wordPrev == "gələn":
                if dayOffset <= 2:
                    dayOffset += 7
                used += 1
                start -= 1
            elif wordPrev == "keçən":
                dayOffset -= 7
                used += 1
                start -= 1
        # parse 15 of July, June 20th, Feb 18, 19 of February
        elif word in months or word in monthsShort and not fromFlag:
            try:
                m = months.index(word)
            except ValueError:
                m = monthsShort.index(word)
            used += 1
            datestr = eng_months[m]
            if wordPrev and wordPrev[0].isdigit():
                datestr += " " + wordPrev
                start -= 1
                used += 1
                if wordNext and wordNext[0].isdigit():
                    datestr += " " + wordNext
                    used += 1
                    hasYear = True
                    if (wordNextNext and wordNextNext in markers) or wordNextNext == 'il':
                        used += 1
                else:
                    if wordNext and wordNext in markers:
                        used += 1
                    hasYear = False

            elif wordNext and wordNext[0].isdigit():
                datestr += " " + wordNext
                used += 1
                if wordNextNext and wordNextNext[0].isdigit():
                    datestr += " " + wordNextNext
                    used += 1
                    hasYear = True
                    if wordNextNextNext and wordNextNextNext in markers:
                        used += 1
                else:
                    if wordNextNext and wordNextNext in markers:
                        used += 1
                    hasYear = False

        elif word == "bu":
            used += 1
            dayOffset = 0
            if wordNext in markers:
                used += 1
        
        if used > 0:
            for i in range(0, used):
                words[i + start] = ""

            if start - 1 >= 0 and words[start - 1] in markers:
                words[start - 1] = ""
            found = True
            daySpecified = True

    # parse time
    hrOffset = 0
    minOffset = 0
    secOffset = 0
    hrAbs = None
    minAbs = None
    military = False

    for idx, word in enumerate(words):
        if word == "":
            continue
        wordPrevPrev = words[idx - 2] if idx > 1 else ""
        wordPrev = words[idx - 1] if idx > 0 else ""
        wordNext = words[idx + 1] if idx + 1 < len(words) else ""
        wordNextNext = words[idx + 2] if idx + 2 < len(words) else ""
        # parse günorta, gecə yarısı, səhər, günortadan sonra, axşam, gecə
        used = 0
        if word == "günorta":
            hrAbs = 12
            used += 1
        elif word == "gecə yarısı":
            hrAbs = 0
            used += 1
        elif word == "səhər":
            if hrAbs is None:
                hrAbs = 8
            used += 1
        elif word == "günortadan sonra":
            if hrAbs is None:
                hrAbs = 15
            used += 1
        elif word == "axşam":
            if hrAbs is None:
                hrAbs = 19
            used += 1
        elif word == "gecə":
            if hrAbs is None:
                hrAbs = 21
            used += 1
        # parse yarım saat
        elif word == "saat":
            if wordPrev == "yarım":
                minOffset = 30
            if wordNext in markers:
                used +=1

            words[idx - 1] = ""
            used += 1
            hrAbs = -1
            minAbs = -1
        # parse 5:00 am, 12:00 p.m., etc
        elif word[0].isdigit():
            isTime = True
            strHH = ""
            strMM = ""
            remainder = ""
            wordNextNextNext = words[idx + 3] \
                if idx + 3 < len(words) else ""

            if ':' in word:
                # parse colons
                # "gecə 3:00"
                stage = 0
                length = len(word)
                for i in range(length):
                    if stage == 0:
                        if word[i].isdigit():
                            strHH += word[i]
                        elif word[i] == ":":
                            stage = 1
                        else:
                            stage = 2
                            i -= 1
                    elif stage == 1:
                        if word[i].isdigit():
                            strMM += word[i]
                        else:
                            stage = 2
                            i -= 1
                    elif stage == 2:
                        remainder = word[i:].replace(".", "")
                        break

            else:
                # try to parse numbers without colons
                # 5 hours, 10 minutes etc.
                length = len(word)
                strNum = ""
                remainder = ""
                for i in range(length):
                    if word[i].isdigit():
                        strNum += word[i]
                    else:
                        remainder += word[i]

                if remainder == "":
                    remainder = wordNext.replace(".", "").lstrip().rstrip()
                if (
                        remainder == "pm" or
                        wordNext == "pm" or
                        remainder == "p.m." or
                        wordNext == "p.m."):
                    strHH = strNum
                    remainder = "pm"
                    used = 1
                elif (
                        remainder == "am" or
                        wordNext == "am" or
                        remainder == "a.m." or
                        wordNext == "a.m."):
                    strHH = strNum
                    remainder = "am"
                    used = 1
                elif (
                        remainder in recur_markers or
                        wordNext in recur_markers or
                        wordNextNext in recur_markers):
                    # Ex: "7 on mondays" or "3 this friday"
                    # Set strHH so that isTime == True
                    # when am or pm is not specified
                    strHH = strNum
                    used = 1
                else:
                    if (
                            ("saat" in wordNext or "saat" in remainder) and
                            word[0] != '0' and
                            (
                                int(strNum) < 100 or
                                int(strNum) > 2400
                            )):
                        # "3 saat"
                        hrOffset = int(strNum)
                        used = 1
                        isTime = False
                        hrAbs = -1
                        minAbs = -1
                    elif "dəqiqə" in wordNext or "dəqiqə" in wordNext:
                        # "10 dəqiqə"
                        minOffset = int(strNum)
                        used = 2
                        isTime = False
                        hrAbs = -1
                        minAbs = -1
                        if wordNextNext in markers:
                            used += 1
                    elif "saniyə" in wordNext or "saniyə" in remainder:
                        # 5 saniyə
                        secOffset = int(strNum)
                        used = 2
                        isTime = False
                        hrAbs = -1
                        minAbs = -1
                    elif wordNext and wordNext[0].isdigit():
                        # military time, e.g. "04 38 hours"
                        strHH = strNum
                        strMM = wordNext
                        military = True
                        used += 1
                        if (wordNextNext and wordNextNext == "da" or
                                wordNextNext == "də" or
                                remainder == "da" or remainder == "də"):
                            used += 1
                    elif wordNext in markers:
                        strHH = strNum

            HH = int(strHH) if strHH else 0
            MM = int(strMM) if strMM else 0
            if timeQualifier in timeQualifiersPM and HH < 12:
                HH += 12
            
            if HH > 24 or MM > 59:
                isTime = False
                used = 0
            if isTime:
                hrAbs = HH
                minAbs = MM
                used += 1
            
            if wordNext in markers or word in markers:
                used += 1
        if used > 0:
            # removed parsed words from the sentence
            for i in range(used):
                if idx + i >= len(words):
                    break
                words[idx + i] = ""
    # check that we found a date
    if not date_found():
        return None

    if dayOffset is False:
        dayOffset = 0

    # perform date manipulation

    extractedDate = anchorDate.replace(microsecond=0)

    if datestr != "":
        # date included an explicit date, e.g. "iyun 5" or "iyun 2, 2017"
        try:
            temp = datetime.strptime(datestr, "%B %d")
        except ValueError:
            # Try again, allowing the year
            temp = datetime.strptime(datestr, "%B %d %Y")
        extractedDate = extractedDate.replace(hour=0, minute=0, second=0)
        if not hasYear:
            temp = temp.replace(year=extractedDate.year,
                                tzinfo=extractedDate.tzinfo)
            if extractedDate < temp:
                extractedDate = extractedDate.replace(
                    year=int(currentYear),
                    month=int(temp.strftime("%m")),
                    day=int(temp.strftime("%d")),
                    tzinfo=extractedDate.tzinfo)
            else:
                extractedDate = extractedDate.replace(
                    year=int(currentYear) + 1,
                    month=int(temp.strftime("%m")),
                    day=int(temp.strftime("%d")),
                    tzinfo=extractedDate.tzinfo)
        else:
            extractedDate = extractedDate.replace(
                year=int(temp.strftime("%Y")),
                month=int(temp.strftime("%m")),
                day=int(temp.strftime("%d")),
                tzinfo=extractedDate.tzinfo)
    else:
        # ignore the current HH:MM:SS if relative using days or greater
        if hrOffset == 0 and minOffset == 0 and secOffset == 0:
            extractedDate = extractedDate.replace(hour=0, minute=0, second=0)

    if yearOffset != 0:
        extractedDate = extractedDate + relativedelta(years=yearOffset)
    if monthOffset != 0:
        extractedDate = extractedDate + relativedelta(months=monthOffset)
    if dayOffset != 0:
        extractedDate = extractedDate + relativedelta(days=dayOffset)
    if hrAbs != -1 and minAbs != -1:
        # If no time was supplied in the string set the time to default
        # time if it's available
        if hrAbs is None and minAbs is None and default_time is not None:
            hrAbs, minAbs = default_time.hour, default_time.minute
        else:
            hrAbs = hrAbs or 0
            minAbs = minAbs or 0

        extractedDate = extractedDate + relativedelta(hours=hrAbs,
                                                      minutes=minAbs)
        if (hrAbs != 0 or minAbs != 0) and datestr == "":
            if not daySpecified and anchorDate > extractedDate:
                extractedDate = extractedDate + relativedelta(days=1)
    if hrOffset != 0:
        extractedDate = extractedDate + relativedelta(hours=hrOffset)
    if minOffset != 0:
        extractedDate = extractedDate + relativedelta(minutes=minOffset)
    if secOffset != 0:
        extractedDate = extractedDate + relativedelta(seconds=secOffset)
    for idx, word in enumerate(words):
        if words[idx] == "və" and \
                words[idx - 1] == "" and words[idx + 1] == "":
            words[idx] = ""

    resultStr = " ".join(words)
    resultStr = ' '.join(resultStr.split())
    return [extractedDate, resultStr]


def is_fractional_az(input_str, short_scale=True, spoken=True):
    """
    This function takes the given text and checks if it is a fraction.

    Args:
        input_str (str): the string to check if fractional
        short_scale (bool): use short scale if True, long scale if False
        spoken (bool):
    Returns:
        (bool) or (float): False if not a fraction, otherwise the fraction

    """

    fracts = {"dörddəbir": 4, "yarım": 2, "üçdəbir": 3}
    for num in _FRACTION_STRING_AZ:
        if num > 2:
            fracts[_FRACTION_STRING_AZ[num]] = num

    if input_str.lower() in fracts and spoken:
        return 1.0 / fracts[input_str.lower()]
    return False


def extract_numbers_az(text, short_scale=True, ordinals=False):
    """
        Takes in a string and extracts a list of numbers.

    Args:
        text (str): the string to extract a number from
        short_scale (bool): Use "short scale" or "long scale" for large
            numbers -- over a million.  The default is short scale, which
            is now common in most English speaking countries.
            See https://en.wikipedia.org/wiki/Names_of_large_numbers
        ordinals (bool): consider ordinal numbers, e.g. third=3 instead of 1/3
    Returns:
        list: list of extracted numbers as floats
    """
    results = _extract_numbers_with_text_az(tokenize(text),
                                            short_scale, ordinals)
    return [float(result.value) for result in results]


class AzerbaijaniNormalizer(Normalizer):
    with open(resolve_resource_file("text/az-az/normalize.json")) as f:
        _default_config = json.load(f)

    def numbers_to_digits(self, utterance):
        return _convert_words_to_numbers_az(utterance, ordinals=None)


def normalize_az(text, remove_articles=True):
    """ Azerbaijani string normalization """
    return AzerbaijaniNormalizer().normalize(text, remove_articles)
