# The following lines are replaced during the release process.
# START_VERSION_BLOCK
VERSION_MAJOR = 0
VERSION_MINOR = 4
VERSION_BUILD = 8
VERSION_ALPHA = 1
# END_VERSION_BLOCK
