# The following lines are replaced during the release process.
# START_VERSION_BLOCK
VERSION_MAJOR = 0
VERSION_MINOR = 2
VERSION_BUILD = 7
VERSION_ALPHA = 5
# END_VERSION_BLOCK
