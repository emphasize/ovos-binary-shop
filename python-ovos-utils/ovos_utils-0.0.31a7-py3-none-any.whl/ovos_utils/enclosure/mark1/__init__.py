from ovos_utils.enclosure.api import EnclosureAPI


class Mark1EnclosureAPI(EnclosureAPI):
    """ Mark1 enclosure, messagebus API"""
