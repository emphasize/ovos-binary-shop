from ovos_workshop.decorators.fallback_handler import *
# backwards compat import
