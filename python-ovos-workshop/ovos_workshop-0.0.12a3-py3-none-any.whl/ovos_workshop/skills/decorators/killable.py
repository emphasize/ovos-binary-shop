from ovos_workshop.decorators.killable import *
# backwards compat import
