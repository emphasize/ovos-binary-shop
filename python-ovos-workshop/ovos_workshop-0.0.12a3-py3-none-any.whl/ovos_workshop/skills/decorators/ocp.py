from ovos_workshop.decorators.ocp import *
# backwards compat import
