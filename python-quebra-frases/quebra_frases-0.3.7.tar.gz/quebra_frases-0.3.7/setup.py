from setuptools import setup

setup(
    name='quebra_frases',
    version='0.3.7',
    packages=['quebra_frases'],
    url='https://github.com/OpenJarbas/quebra_frases',
    license='apache-2.0',
    author='jarbasAi',
    author_email='jarbasai@mailfence.com',
    description='quebra_frases chunks strings into byte sized pieces'
)
