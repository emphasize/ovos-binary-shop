Usage
=====

.. toctree::
   :maxdepth: 3

   process
   distance/index
   fuzz
   string_metric
   utils
