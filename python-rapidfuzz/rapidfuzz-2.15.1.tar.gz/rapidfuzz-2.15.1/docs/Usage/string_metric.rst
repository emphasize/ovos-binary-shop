rapidfuzz.string_metric
=======================

levenshtein
-----------
.. autofunction:: rapidfuzz.string_metric.levenshtein

normalized_levenshtein
----------------------
.. autofunction:: rapidfuzz.string_metric.normalized_levenshtein

hamming
-------
.. autofunction:: rapidfuzz.string_metric.hamming

normalized_hamming
------------------
.. autofunction:: rapidfuzz.string_metric.normalized_hamming

jaro_similarity
---------------
.. autofunction:: rapidfuzz.string_metric.jaro_similarity

jaro_winkler_similarity
-----------------------
.. autofunction:: rapidfuzz.string_metric.jaro_winkler_similarity
